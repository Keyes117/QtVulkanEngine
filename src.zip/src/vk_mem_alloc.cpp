#define VMA_IMPLEMENTATION
#include "vma/vk_mem_alloc.h"

